from gpiozero import LED
from time import sleep

led = LED(25)

while True:
    print('Encendido LED')
    led.on()
    sleep(3)
    print('Apagado LED')
    led.off()
    sleep(3)
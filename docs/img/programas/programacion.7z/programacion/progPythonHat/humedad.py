from sense_emu import SenseHat

sense = SenseHat()
humidity = sense.get_humidity()
print("Humedad: %s%% rH" % humidity)

# alternativas
print(sense.humidity)
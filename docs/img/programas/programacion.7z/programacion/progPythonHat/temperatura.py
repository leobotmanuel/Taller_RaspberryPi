from sense_emu import SenseHat

sense = SenseHat()
temp = sense.get_temperature()
print("Temperatura: %sºC" % temp)

# alternativas
print(sense.temp)
print(sense.temperature)
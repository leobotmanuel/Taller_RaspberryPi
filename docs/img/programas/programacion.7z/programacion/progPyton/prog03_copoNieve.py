#incluye librerias
import turtle
import random
#declara pat como objeto 
pat = turtle.Turtle()
turtle.Screen().bgcolor("grey")
#lista de colores
colours = ["cyan", "purple", "white", "blue"]
#movimiento inicial de la tortuga
pat.penup()
pat.forward(90)
pat.left(45)
pat.pendown()
#función dibujar los brazos
def branch():
    for i in range(3):
        for i in range(3):
            pat.forward(30)
            pat.backward(30)
            pat.right(45)
        pat.left(90)
        pat.backward(30)
        pat.left(45)
    pat.right(90)
    pat.forward(90)
#repetir 8 brazos
for i in range(8):
    branch()	
    pat.left(45)
    pat.color(random.choice(colours))

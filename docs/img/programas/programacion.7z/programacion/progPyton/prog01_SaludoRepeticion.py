#Programa básico

print("¡Hola Mundo de la programación\n")
print("Voy a contar de 0 a 9")

print("Empiezo el bucle repetitivo")
for i in range(10):
    print(i)
print("¡Se acabó el bucle")

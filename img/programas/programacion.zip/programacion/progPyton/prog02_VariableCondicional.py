#Programa manejo de varible ante dato de entrada y
#manejo de la estructura de control condicional

#Escribe en la consola la pregunta y espera la respuesta
amigo = input("¿Cómo te llamas: ")

if amigo == "Manuel":
    print("Eres mi amigo.")
else:
    print("¡No Eres mi amigo!")
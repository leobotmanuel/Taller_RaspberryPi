#Programa manejo de varible ante dato de entrada y
#manejo de la estructura de control condicional

#Escribe en la consola la pregunta y espera la respuesta
#repite la pregunta hasta que da el nombre correcto
amigo = input("¿Cómo te llamas: ")

while amigo != "Manuel":
    print("No eres mi amigo. ¡Vuelve a intertarlo!\n")
    amigo = input("¿Cómo te llamas: ")
print("¡Eres mi amigo")
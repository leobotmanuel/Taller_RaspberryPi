from sense_emu import SenseHat
sHat = SenseHat()

sHat.show_message("Hola Raspberri Pi")